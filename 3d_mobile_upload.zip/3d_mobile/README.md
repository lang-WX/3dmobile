# 3D采集 · 手机版（安卓 APK）

只做 **搜索 + 下载查看**：
- 站内搜索（作者 / 小类 / 标题片段，可按彩种、可选期号）
- 下载后**条件保持原样**（站点返回的原文，不做任何转换）
- **不导出 Excel、不写文件**，要数据就点「复制内容 / 复制本页全部」

## 功能
- 彩种：福彩3D / 排列三 / 双色球
- 关键词 + 期号（期号可留空）
- 结果列表：标题、作者、小类、期号、价格、连红、命中
- 每条：⬇ 下载/查看（原样内容弹窗）、📋 复制内容
- 底部：上一页 / 下一页 / 复制本页全部
- 中文界面（自带 msyh 字体）

## 电脑上先跑（Windows，已装 Kivy 2.3.1 的 Python）
```bash
cd 3d_mobile
python main.py
```

## 打包 APK
### 方法一：GitHub Actions 云构建（推荐，不用装 Linux/安卓 SDK）
1. GitHub 新建仓库，把 `3d_mobile` 整个文件夹传上去（含 `main.py`、`buildozer.spec`、`.github/`、`fonts/`）
2. 仓库 → **Actions** → 左侧 **Build Android APK** → **Run workflow**
3. 15~30 分钟后在运行结果的 **Artifacts** 里下载 `3d-mobile-apk`（里面是 `*.apk`）
4. 把 APK 发到安卓手机，允许"安装未知来源应用"安装即可

### 方法二：WSL + Buildozer 本地构建
```bash
sudo apt update && sudo apt install -y git zip unzip openjdk-17-jdk python3-pip \
  autoconf libtool pkg-config zlib1g-dev libncurses5-dev cmake libffi-dev libssl-dev
pip3 install --user buildozer cython
cd 3d_mobile
buildozer -v android debug     # 产物在 bin/*.apk
```

## 说明
- 只用标准库 `urllib` 访问站点公开接口，不需要登录、不存任何账号。
- 手机端剪贴板用 Kivy `Clipboard`，复制后可直接粘贴到微信/笔记。
- 搜索接口每页 10 条；「复制本页全部」会逐条读取原文（约 10 次请求，稍等几秒）。
