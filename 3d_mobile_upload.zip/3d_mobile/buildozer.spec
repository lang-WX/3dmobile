﻿[app]
title = 3D采集手机版
package.name = c3dmobile
package.domain = org.dsh
source.dir = .
source.include_exts = py,png,jpg,ttc,ttf,json,txt
source.exclude_patterns = build,dist,__pycache__,*.pyc,bin
version = 1.0.0
requirements = python3,kivy==2.3.1
orientation = portrait
fullscreen = 0
android.permissions = INTERNET
android.api = 33
android.minapi = 21
android.ndk_api = 21
android.archs = arm64-v8a
android.allow_backup = True
android.accept_sdk_license = True
android.logcat_filters = *:S python:D
p4a.bootstrap = sdl2

[buildozer]
log_level = 2
warn_on_root = 1
