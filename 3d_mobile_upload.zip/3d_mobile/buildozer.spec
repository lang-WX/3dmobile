[app]
title = 3D采集手机版
package.name = c3dmobile
package.domain = org.dsh
source.dir = .
source.include_exts = py,png,jpg,ttc,ttf,json,txt
source.exclude_patterns = build,dist,__pycache__,*.pyc,bin,*.log
version = 3.1.0
requirements = python3,kivy
orientation = portrait
fullscreen = 0
android.permissions = INTERNET
android.api = 31
android.minapi = 21
android.ndk = 25b
android.ndk_api = 21
android.archs = arm64-v8a,x86_64
android.allow_backup = True
android.accept_sdk_license = True
android.logcat_filters = *:S python:D
p4a.bootstrap = sdl2

[buildozer]
log_level = 2
warn_on_root = 1
