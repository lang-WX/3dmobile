# -*- coding: utf-8 -*-
"""3D采集 · 手机版 v4（Kivy）
- 作者：输入框，想搜谁就搜谁（默认带出热门作者可点）
- 期号：自动取站点最新期，填入输入框，可改
- 小类：下拉（全部/直选大底/…）
- 只做：搜索、下载看原文（条件原样）、复制；不导出、不转换
- 免费卡排前面（付费卡站点只返回“请支付宝币”的提示）
- 全程 try/except + 弹窗报错 + mobile.log；键盘不遮挡输入框
"""
import json
import os
import sys
import threading
import time
import traceback
import urllib.parse
import urllib.request

from kivy.app import App
from kivy.clock import Clock, mainthread
from kivy.core.clipboard import Clipboard
from kivy.core.text import LabelBase
from kivy.core.window import Window
from kivy.metrics import dp
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.gridlayout import GridLayout
from kivy.uix.label import Label
from kivy.uix.popup import Popup
from kivy.uix.scrollview import ScrollView
from kivy.uix.spinner import Spinner
from kivy.uix.textinput import TextInput

Window.softinput_mode = 'below_target'

BASE = 'https://app.weice888.cn'
UA = ('Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 '
      '(KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36')

LOTS = [
    ('福彩3D', 1, ['全部', '直选大底', '直选定位', '跨度', '和值', '和尾', '分解', '断组',
                   '杀码', '和差', '两码合', '胆码', '双飞', '组选复式', '杀垃圾']),
    ('排列三', 2, ['全部', '直选大底', '直选定位', '跨度', '和值', '和尾', '分解', '断组',
                   '杀码', '和差', '两码合', '胆码', '双飞', '组选复式', '杀垃圾']),
    ('双色球', 5, ['全部', '红球定胆', '蓝球定胆', '红球杀号', '蓝球杀号', '冷热分析',
                   '遗漏分析', '欲出几率']),
]

C_BG = (0.96, 0.97, 0.99, 1)
C_CARD = (1, 1, 1, 1)
C_PRIMARY = (0.10, 0.14, 0.50, 1)
C_PRIMARY2 = (0.23, 0.29, 0.68, 1)
C_TEXT = (0.10, 0.12, 0.16, 1)
C_MUT = (0.45, 0.50, 0.58, 1)
C_LINE = (0.88, 0.90, 0.94, 1)
C_ACCENT = (0.91, 0.94, 1.0, 1)
C_INPUT = (0.97, 0.98, 1, 1)

_HERE = os.path.dirname(os.path.abspath(__file__))
_FONT = os.path.join(_HERE, 'fonts', 'msyh.ttc')
if os.path.exists(_FONT):
    try:
        LabelBase.register(name='cjk', fn_regular=_FONT)
        FONT = 'cjk'
    except Exception:
        FONT = 'Roboto'
else:
    FONT = 'Roboto'

LOG_PATH = os.path.join(_HERE, 'mobile.log')


def log(msg):
    try:
        with open(LOG_PATH, 'a', encoding='utf-8') as f:
            f.write('[%s] %s\n' % (time.strftime('%m-%d %H:%M:%S'), msg))
    except Exception:
        pass


def _get(url, timeout=20, retries=2):
    last = None
    for _ in range(retries + 1):
        try:
            req = urllib.request.Request(url, headers={
                'User-Agent': UA,
                'Accept': 'application/json, text/plain, */*',
            })
            with urllib.request.urlopen(req, timeout=timeout) as r:
                raw = r.read().decode('utf-8', 'replace')
            return json.loads(raw)
        except Exception as e:
            last = e
            time.sleep(0.8)
    raise last


def fetch_list(zone, page=1, son='全部'):
    url = ('%s/addons/ask/api.article/index?zone_id=%d&category_id=0&zhong=0&page=%d'
           '&son_title=%s&type=0' % (BASE, zone, page, urllib.parse.quote(str(son))))
    return _get(url, timeout=15)


def fetch_search(kw, issue, zone, page=1):
    parts = []
    if issue:
        parts.append(str(issue).strip() + '期')
    if kw:
        parts.append(str(kw).strip())
    q = ' '.join(parts).strip()
    url = ('%s/addons/ask/api.search/index?module=article&q=%s&page=%d&zone_id=%d'
           % (BASE, urllib.parse.quote(q), page, zone))
    return _get(url)


def fetch_show(aid):
    return _get('%s/addons/ask/api.article/show?id=%s&order=default'
                % (BASE, urllib.parse.quote(str(aid))))


def rows_of(j):
    if not j:
        return []
    d = j.get('data') or {}
    a = d.get('data')
    if isinstance(a, dict):
        a = a.get('data')
    return a if isinstance(a, list) else []


def article_of(j):
    return ((j or {}).get('data') or {}).get('article') or {}


def _is_locked_text(body):
    b = str(body or '')
    if not b.strip():
        return True
    if ('温馨提示' in b) or ('宝币' in b) or ('请先支付' in b):
        return True
    return len(b.strip()) < 60


def _walk_strs(node, out):
    if isinstance(node, str):
        if node.strip():
            out.append(node.strip())
    elif isinstance(node, dict):
        for k in ('opt', 'data', 'value'):
            if k in node:
                _walk_strs(node[k], out)
    elif isinstance(node, list):
        for x in node:
            _walk_strs(x, out)


def summary_text(art):
    """把 summary 摘要还原成人类可读的号码文本（电脑版就是这么做的）"""
    sm = art.get('summary') or []
    out_all = []
    for block in sm:
        if not isinstance(block, dict):
            continue
        name = str(block.get('name') or '').strip()
        data = block.get('data') or []
        lines = []
        if not data:
            continue
        # 直选大底 / 各种“一堆三位号”
        first = data[0] if isinstance(data, list) and data else None
        if isinstance(first, list) and first and all(isinstance(x, str) for x in first):
            lines.append(' '.join(x for x in first if str(x).strip()))
        else:
            # 组/多段结构：逐组还原
            for group in data:
                if not isinstance(group, list):
                    continue
                if group and all(isinstance(x, dict) for x in group):
                    cell_parts = []
                    for cell in group:
                        opt = cell.get('opt') if isinstance(cell, dict) else None
                        if isinstance(opt, list) and opt:
                            cell_parts.append(''.join(str(o) for o in opt))
                        elif isinstance(cell, dict) and cell.get('value'):
                            cell_parts.append(str(cell.get('value')))
                    if cell_parts:
                        if len(cell_parts) == 3:
                            lines.append('-'.join(p if p else '*' for p in cell_parts))
                        else:
                            lines.append(' '.join(cell_parts))
                else:
                    strs = []
                    _walk_strs(group, strs)
                    if strs:
                        lines.append(' '.join(strs))
        if not lines:
            strs = []
            _walk_strs(data, strs)
            if strs:
                lines.append(' '.join(strs))
        if lines:
            out_all.append((name, '\n'.join(lines)))
    if not out_all:
        return ''
    if len(out_all) == 1:
        return out_all[0][1]
    return '\n\n'.join('[%s]\n%s' % (n, t) for n, t in out_all if t)


def payload_text(art, row=None):
    """优先用正文（条件原样）；正文被锁则用 summary 还原。
    返回 (文本, 来源)，来源 = 'content' / 'summary' / 'locked'"""
    body = str(art.get('content') if art.get('content') is not None else '')
    if not _is_locked_text(body):
        return body, 'content'
    t = summary_text(art)
    if t.strip():
        return t, 'summary'
    return body, 'locked'


def norm_issue(x):
    s = str(x or '').strip().lstrip('0')
    return s or str(x or '')


def is_free(x):
    p = x.get('price')
    return p is None or str(p) in ('0', '0.0', '')


def money_text(x):
    return '免费' if is_free(x) else '¥%s' % x.get('price')


def bg(widget, color):
    from kivy.graphics import Color, Rectangle
    with widget.canvas.before:
        Color(*color)
        r = Rectangle(pos=widget.pos, size=widget.size)

    def _sync(*_):
        r.pos = widget.pos
        r.size = widget.size
    widget.bind(pos=_sync, size=_sync)


class Card(BoxLayout):
    def __init__(self, app, row, **kw):
        super(Card, self).__init__(orientation='vertical', size_hint_y=None,
                                   height=dp(136), padding=(dp(10), dp(8)),
                                   spacing=dp(4), **kw)
        bg(self, C_CARD)
        self.app = app
        self.row = row
        self.add_widget(Label(text=str(row.get('title') or ''), font_name=FONT,
                              font_size=dp(14), bold=True, color=C_TEXT, halign='left',
                              valign='middle', size_hint_y=None, height=dp(46),
                              shorten=True, shorten_from='right',
                              text_size=(dp(280), dp(46))))
        meta = '👤 %s    🏷 %s    📅 %s    %s' % (
            row.get('author') or '', row.get('son_title') or '',
            norm_issue(row.get('issue_no')), money_text(row))
        self.add_widget(Label(text=meta, font_name=FONT, font_size=dp(11),
                              color=(0.18, 0.55, 0.24, 1) if is_free(row) else C_MUT,
                              halign='left', valign='middle', size_hint_y=None,
                              height=dp(20), shorten=True, shorten_from='right',
                              text_size=(dp(280), dp(20))))
        acts = BoxLayout(size_hint_y=None, height=dp(40), spacing=dp(8))
        b1 = Button(text='⬇ 下载/查看', font_name=FONT, font_size=dp(13),
                    background_normal='', background_color=C_PRIMARY, color=(1, 1, 1, 1))
        b1.bind(on_release=lambda *a: self.app.open_detail(row))
        b2 = Button(text='📋 复制内容', font_name=FONT, font_size=dp(13),
                    background_normal='', background_color=C_ACCENT, color=C_PRIMARY)
        b2.bind(on_release=lambda *a: self.app.copy_row_content(row))
        acts.add_widget(b1)
        acts.add_widget(b2)
        self.add_widget(acts)


class MainUI(BoxLayout):
    def __init__(self, **kw):
        super(MainUI, self).__init__(orientation='vertical', **kw)
        bg(self, C_BG)
        self.page = 1
        self.rows = []
        self.zone = 1
        self.busy = False
        self.latest_short = ''

        # 顶部
        bar = BoxLayout(orientation='horizontal', size_hint_y=None, height=dp(52),
                        padding=(dp(12), 0), spacing=dp(8))
        bg(bar, C_PRIMARY)
        bar.add_widget(Label(text='3D采集', font_name=FONT, font_size=dp(18), bold=True,
                             color=(1, 1, 1, 1), halign='left', valign='middle'))
        self.sp_lot = Spinner(text='福彩3D', values=[x[0] for x in LOTS], font_name=FONT,
                              font_size=dp(13), size_hint=(None, None), size=(dp(96), dp(34)),
                              background_normal='', background_color=C_PRIMARY2,
                              color=(1, 1, 1, 1))
        self.sp_lot.bind(text=self._on_lot)
        bar.add_widget(self.sp_lot)
        self.add_widget(bar)

        # 输入区：作者 + 搜索
        box1 = BoxLayout(size_hint_y=None, height=dp(54), padding=(dp(10), dp(8)),
                         spacing=dp(8))
        bg(box1, C_CARD)
        self.ti_author = TextInput(text='', hint_text='输入作者（如：华迪）', font_name=FONT,
                                   font_size=dp(15), multiline=False, write_tab=False,
                                   background_normal='', background_active='',
                                   background_color=C_INPUT, foreground_color=C_TEXT,
                                   cursor_color=C_PRIMARY, padding=(dp(10), dp(12)))
        self.ti_author.bind(on_text_validate=lambda *a: self.search(1))
        box1.add_widget(self.ti_author)
        self.btn_go = Button(text='搜索', font_name=FONT, font_size=dp(15), bold=True,
                             size_hint_x=None, width=dp(74), background_normal='',
                             background_color=C_PRIMARY, color=(1, 1, 1, 1))
        self.btn_go.bind(on_release=lambda *a: self.search(1))
        box1.add_widget(self.btn_go)
        self.add_widget(box1)

        # 第二行：期号 + 小类 + 最新期
        box2 = BoxLayout(size_hint_y=None, height=dp(50), padding=(dp(10), 0),
                         spacing=dp(8))
        bg(box2, C_CARD)
        self.ti_issue = TextInput(text='', hint_text='期号(自动)', font_name=FONT,
                                  font_size=dp(14), multiline=False, input_filter='int',
                                  size_hint_x=None, width=dp(96), background_normal='',
                                  background_active='', background_color=C_INPUT,
                                  foreground_color=C_TEXT, cursor_color=C_PRIMARY,
                                  padding=(dp(10), dp(10)))
        box2.add_widget(self.ti_issue)
        self.sp_cat = Spinner(text='全部', values=LOTS[0][2], font_name=FONT,
                              font_size=dp(13), background_normal='',
                              background_color=C_ACCENT, color=C_PRIMARY)
        box2.add_widget(self.sp_cat)
        btn_latest = Button(text='最新期', font_name=FONT, font_size=dp(12),
                            size_hint_x=None, width=dp(72), background_normal='',
                            background_color=C_ACCENT, color=C_PRIMARY)
        btn_latest.bind(on_release=lambda *a: self.reload_meta())
        box2.add_widget(btn_latest)
        self.add_widget(box2)

        self.status = Label(text='正在获取最新期号…', font_name=FONT, font_size=dp(12),
                            color=C_MUT, size_hint_y=None, height=dp(26),
                            halign='left', valign='middle', padding=(dp(12), 0),
                            shorten=True, shorten_from='right')
        self.status.bind(size=lambda *a: setattr(self.status, 'text_size',
                                                 (self.status.width, None)))
        self.add_widget(self.status)

        self.sv = ScrollView(bar_width=dp(4))
        self.listbox = BoxLayout(orientation='vertical', size_hint_y=None,
                                 spacing=dp(8), padding=(dp(8), dp(4)))
        self.listbox.bind(minimum_height=self.listbox.setter('height'))
        self.sv.add_widget(self.listbox)
        self.add_widget(self.sv)

        bar2 = BoxLayout(size_hint_y=None, height=dp(52), spacing=dp(8),
                         padding=(dp(10), dp(8)))
        bg(bar2, C_CARD)
        b_prev = Button(text='上一页', font_name=FONT, font_size=dp(13),
                        background_normal='', background_color=C_ACCENT, color=C_PRIMARY)
        b_prev.bind(on_release=lambda *a: self.search(max(1, self.page - 1)))
        self.pg = Label(text='第 1 页', font_name=FONT, font_size=dp(12), color=C_MUT)
        b_next = Button(text='下一页', font_name=FONT, font_size=dp(13),
                        background_normal='', background_color=C_ACCENT, color=C_PRIMARY)
        b_next.bind(on_release=lambda *a: self.search(self.page + 1))
        b_all = Button(text='复制本页全部', font_name=FONT, font_size=dp(13),
                       background_normal='', background_color=C_PRIMARY, color=(1, 1, 1, 1))
        b_all.bind(on_release=lambda *a: self.copy_page())
        bar2.add_widget(b_prev)
        bar2.add_widget(self.pg)
        bar2.add_widget(b_next)
        bar2.add_widget(b_all)
        self.add_widget(bar2)

        Clock.schedule_once(lambda dt: self.reload_meta(), 0.5)

    # ---------- 工具 ----------
    def say(self, msg, secs=4):
        try:
            self.status.text = msg
            Clock.schedule_once(lambda *a: setattr(self.status, 'text', ''), secs)
        except Exception:
            pass

    def _copy(self, txt):
        try:
            Clipboard.copy(txt or '')
            return True
        except Exception as e:
            self.say('复制失败：%s' % e, 5)
            return False

    def _on_lot(self, sp, txt):
        for nm, z, cats in LOTS:
            if nm == txt:
                self.zone = z
                self.sp_cat.values = cats
                self.sp_cat.text = '全部'
        self.reload_meta()

    # ---------- 最新期 ----------
    def reload_meta(self):
        zone = self.zone
        self.say('正在获取最新期号…', 10)

        def work():
            best = ''
            try:
                rows = rows_of(fetch_list(zone, 1, '全部'))
                if not rows:
                    rows = rows_of(fetch_list(zone, 1, ''))
                for r in rows:
                    d = ''.join(ch for ch in str(r.get('issue_no') or '') if ch.isdigit())
                    if len(d) > len(best) or (len(d) == len(best) and d > best):
                        best = d
            except Exception as e:
                log('latest fail: %r' % (e,))
            Clock.schedule_once(lambda *a: self._latest_done(best), 0)

        threading.Thread(target=work, daemon=True).start()

    @mainthread
    def _latest_done(self, full):
        if full and len(full) >= 3:
            self.latest_short = full[-3:]
            # 默认按“最新一期”搜：正文被锁时程序会自动用站点摘要还原号码（与电脑版一致）
            self.ti_issue.text = self.latest_short
            self.say('最新期 %s（已自动填入；正文被锁时自动用摘要还原号码）' % full, 8)
        else:
            self.say('没取到最新期号，可手填（不填=不限期号）', 6)

    # ---------- 搜索 ----------
    def search(self, page):
        if self.busy:
            return
        if page < 1:
            page = 1
        self.busy = True
        self.btn_go.disabled = True
        self.say('搜索中…', 30)
        issue = (self.ti_issue.text or '').strip()
        author = (self.ti_author.text or '').strip()
        cat = (self.sp_cat.text or '').strip()
        if cat in ('全部', '小类'):
            cat = ''
        kw = ' '.join(x for x in (author, cat) if x).strip()
        zone = self.zone

        def work():
            try:
                rows = rows_of(fetch_search(kw, issue, zone, page))
                note = ''
                if not rows and issue:
                    rows = rows_of(fetch_search(kw, '', zone, page))
                    if rows:
                        note = '「%s期」没有，已按不限期号显示' % issue
                # 免费卡排前面
                rows.sort(key=lambda r: 0 if is_free(r) else 1)
                Clock.schedule_once(lambda *a: self._rows_done(rows, page, note), 0)
            except Exception as e:
                log('search fail: %r\n%s' % (e, traceback.format_exc()))
                Clock.schedule_once(lambda *a: self._fail('搜索失败', e), 0)
        threading.Thread(target=work, daemon=True).start()

    @mainthread
    def _fail(self, title, err):
        self.busy = False
        self.btn_go.disabled = False
        self.say('%s：%s' % (title, err), 8)
        try:
            Popup(title=title, content=Label(text=str(err)[:400], font_name=FONT,
                                             font_size=dp(12), color=C_TEXT),
                  size_hint=(0.9, 0.4)).open()
        except Exception:
            pass

    @mainthread
    def _rows_done(self, rows, page, note=''):
        try:
            self.busy = False
            self.btn_go.disabled = False
            self.rows = rows
            self.page = page
            self.listbox.clear_widgets()
            if not rows:
                self.listbox.add_widget(Label(text='没有结果\n换个作者/小类，或清空期号', font_name=FONT,
                                              font_size=dp(13), color=C_MUT,
                                              size_hint_y=None, height=dp(90)))
                self.pg.text = '第 %d 页' % page
                self.say('没有结果', 5)
                return
            app = App.get_running_app()
            for r in rows:
                self.listbox.add_widget(Card(app, r))
            self.sv.scroll_y = 1
            self.pg.text = '第 %d 页 · %d 条' % (page, len(rows))
            free_n = sum(1 for r in rows if is_free(r))
            self.say(note or ('本页 %d 条（免费 %d）' % (len(rows), free_n)), 6 if note else 4)
        except Exception as e:
            log('render fail: %r\n%s' % (e, traceback.format_exc()))
            self._fail('界面出错', e)

    # ---------- 详情 ----------
    def open_detail(self, row):
        self.say('读取中…', 30)
        ident = row.get('id')

        def work():
            try:
                art = article_of(fetch_show(ident))
                Clock.schedule_once(lambda *a: self._detail_done(row, art), 0)
            except Exception as e:
                log('detail fail: %r' % (e,))
                Clock.schedule_once(lambda *a: self._fail('读取失败', e), 0)
        threading.Thread(target=work, daemon=True).start()

    @mainthread
    def _detail_done(self, row, art):
        try:
            title = str(art.get('title') or row.get('title') or '')
            body, src = payload_text(art, row)
            paid = not is_free(row)
            meta = '作者 %s   小类 %s   期号 %s   %s   原文 %s 字' % (
                art.get('author') or row.get('author') or '',
                art.get('son_title') or row.get('son_title') or '',
                norm_issue(art.get('issue_no') or row.get('issue_no')),
                money_text(row), art.get('content_len') or len(body))
            box = BoxLayout(orientation='vertical', padding=dp(10), spacing=dp(8))
            bg(box, C_CARD)
            box.add_widget(Label(text=title, font_name=FONT, font_size=dp(14), bold=True,
                                 color=C_TEXT, size_hint_y=None, height=dp(44),
                                 halign='left', valign='middle', shorten=True,
                                 shorten_from='right'))
            box.add_widget(Label(text=meta, font_name=FONT, font_size=dp(11), color=C_MUT,
                                 size_hint_y=None, height=dp(20), shorten=True,
                                 shorten_from='right'))
            sv = ScrollView()
            lb = Label(text=body, font_name=FONT, font_size=dp(14), color=C_TEXT,
                       halign='left', valign='top', size_hint_y=None)
            lb.bind(width=lambda *a: setattr(lb, 'text_size', (lb.width, None)),
                    texture_size=lambda *a: setattr(lb, 'height', lb.texture_size[1]))
            sv.add_widget(lb)
            box.add_widget(sv)
            locked = (src == 'locked')
            if src == 'summary':
                box.add_widget(Label(text='ℹ 正文被站点锁了，下面是从站点「摘要」还原出来的号码（与电脑版采集器同源）。',
                                     font_name=FONT, font_size=dp(11),
                                     color=(0.12, 0.45, 0.20, 1), size_hint_y=None,
                                     height=dp(40), halign='left', valign='middle'))
            elif locked:
                box.add_widget(Label(text='⚠ 这条连摘要都没有，站点没返回号码（换一张卡或换期试试）。',
                                     font_name=FONT, font_size=dp(11),
                                     color=(0.85, 0.35, 0.05, 1), size_hint_y=None,
                                     height=dp(40), halign='left', valign='middle'))
            acts = BoxLayout(size_hint_y=None, height=dp(44), spacing=dp(8))
            b1 = Button(text='📋 复制内容', font_name=FONT, font_size=dp(13),
                        background_normal='', background_color=C_PRIMARY, color=(1, 1, 1, 1))
            b2 = Button(text='📋 标题+内容', font_name=FONT, font_size=dp(13),
                        background_normal='', background_color=C_ACCENT, color=C_PRIMARY)
            b3 = Button(text='关闭', font_name=FONT, font_size=dp(13),
                        background_normal='', background_color=(0.90, 0.91, 0.94, 1),
                        color=C_TEXT)
            b4 = None
            if locked:
                b4 = Button(text='↩ 改用上一期搜索', font_name=FONT, font_size=dp(13),
                            background_normal='', background_color=(1.0, 0.86, 0.62, 1),
                            color=(0.45, 0.22, 0.0, 1))
            pop = Popup(title='内容（条件原样）', content=box, size_hint=(0.96, 0.9),
                        title_font=FONT, title_color=C_TEXT)
            b1.bind(on_release=lambda *a: (self._copy(body), self.say('内容已复制', 3)))
            b2.bind(on_release=lambda *a: (self._copy('【%s】\n%s\n%s' % (title, meta, body)),
                                           self.say('标题+内容已复制', 3)))
            b3.bind(on_release=lambda *a: pop.dismiss())
            if b4 is not None:
                def _prev_issue(*a):
                    pop.dismiss()
                    try:
                        cur = int((self.ti_issue.text or '0').strip() or 0)
                        if cur > 1:
                            self.ti_issue.text = str(cur - 1)
                    except Exception:
                        pass
                    self.search(1)
                b4.bind(on_release=_prev_issue)
            acts.add_widget(b1)
            acts.add_widget(b2)
            if b4 is not None:
                acts.add_widget(b4)
            acts.add_widget(b3)
            box.add_widget(acts)
            pop.open()
            self.say('已下载（原样显示）', 4)
        except Exception as e:
            log('detail render fail: %r\n%s' % (e, traceback.format_exc()))
            self._fail('显示失败', e)

    # ---------- 复制 ----------
    def copy_row_content(self, row):
        self.say('读取中…', 30)
        ident = row.get('id')

        def work():
            try:
                art = article_of(fetch_show(ident))
                body, src = payload_text(art, row)
                n = len([x for x in body.replace('\n', ' ').split() if x])
                tag = '（摘要还原）' if src == 'summary' else ''
                Clock.schedule_once(lambda *a: (self._copy(body),
                                                self.say('已复制 %d 项%s' % (n, tag), 4)), 0)
            except Exception as e:
                log('copy fail: %r' % (e,))
                Clock.schedule_once(lambda *a: self._fail('复制失败', e), 0)
        threading.Thread(target=work, daemon=True).start()

    def copy_page(self):
        if not self.rows:
            self.say('先搜索', 3)
            return
        self.say('正在逐条读取…', 60)
        rows = list(self.rows)

        def work():
            out = []
            for r in rows:
                try:
                    art = article_of(fetch_show(r.get('id')))
                    body, _src = payload_text(art, r)
                    out.append('【%s】\n%s' % (art.get('title') or r.get('title') or '', body))
                except Exception:
                    out.append('【%s】\n（读取失败）' % (r.get('title') or ''))
            Clock.schedule_once(lambda *a: (self._copy('\n\n'.join(out)),
                                            self.say('已复制本页 %d 条' % len(rows), 4)), 0)
        threading.Thread(target=work, daemon=True).start()


class MobileApp(App):
    title = '3D采集 · 手机版'

    def build(self):
        Window.clearcolor = C_BG
        return MainUI()


if __name__ == '__main__':
    try:
        MobileApp().run()
    except Exception:
        log('fatal:\n%s' % traceback.format_exc())
        raise
