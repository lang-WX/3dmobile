# -*- coding: utf-8 -*-
"""3D采集 · 手机版 v2（Kivy）
- 手机风格浅色界面（白底、卡片、大按钮）
- 期号自动取站点最新期（可一键填入，也可手改）
- 搜索/读取全程 try/except，出错弹窗提示并写日志，不再闪退
- 只做：搜索、下载看原文（条件原样）、复制；不导出、不转换
"""
import json
import os
import sys
import threading
import time
import traceback
import urllib.parse
import urllib.request

from kivy.app import App
from kivy.clock import Clock, mainthread
from kivy.core.clipboard import Clipboard
from kivy.core.text import LabelBase
from kivy.core.window import Window
from kivy.metrics import dp
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.popup import Popup
from kivy.uix.scrollview import ScrollView
from kivy.uix.spinner import Spinner
from kivy.uix.textinput import TextInput

BASE = 'https://app.weice888.cn'
UA = ('Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 '
      '(KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36')
LOTS = [('福彩3D', 1), ('排列三', 2), ('双色球', 5)]

# 手机风格色卡
C_BG = (0.96, 0.97, 0.99, 1)
C_CARD = (1, 1, 1, 1)
C_PRIMARY = (0.10, 0.14, 0.50, 1)
C_PRIMARY2 = (0.23, 0.29, 0.68, 1)
C_TEXT = (0.10, 0.12, 0.16, 1)
C_MUT = (0.45, 0.50, 0.58, 1)
C_LINE = (0.88, 0.90, 0.94, 1)
C_ACCENT = (0.91, 0.94, 1.0, 1)

_HERE = os.path.dirname(os.path.abspath(__file__))
_FONT = os.path.join(_HERE, 'fonts', 'msyh.ttc')
if os.path.exists(_FONT):
    try:
        LabelBase.register(name='cjk', fn_regular=_FONT)
        FONT = 'cjk'
    except Exception:
        FONT = 'Roboto'
else:
    FONT = 'Roboto'

LOG_PATH = os.path.join(_HERE, 'mobile.log')


def log(msg):
    try:
        with open(LOG_PATH, 'a', encoding='utf-8') as f:
            f.write('[%s] %s\n' % (time.strftime('%Y-%m-%d %H:%M:%S'), msg))
    except Exception:
        pass


def _get(url, timeout=20, retries=2):
    last = None
    for i in range(retries + 1):
        try:
            req = urllib.request.Request(url, headers={
                'User-Agent': UA,
                'Accept': 'application/json, text/plain, */*',
            })
            with urllib.request.urlopen(req, timeout=timeout) as r:
                raw = r.read().decode('utf-8', 'replace')
            return json.loads(raw)
        except Exception as e:
            last = e
            time.sleep(0.8)
    raise last


def fetch_search(kw, issue, zone, page=1):
    parts = []
    if issue:
        parts.append(str(issue).strip() + '期')
    if kw:
        parts.append(str(kw).strip())
    q = ' '.join(parts).strip()
    url = ('%s/addons/ask/api.search/index?module=article&q=%s&page=%d&zone_id=%d'
           % (BASE, urllib.parse.quote(q), page, zone))
    return _get(url)


def fetch_show(aid):
    url = '%s/addons/ask/api.article/show?id=%s&order=default' % (
        BASE, urllib.parse.quote(str(aid)))
    return _get(url)


def fetch_latest_issue(zone):
    """站点最新列表接口 → 取最大期号，返回 (完整期号, 末3位)"""
    url = ('%s/addons/ask/api.article/index?zone_id=%d&category_id=0&zhong=0&page=1'
           '&son_title=%%E5%%85%%A8%%E9%%83%%A8&type=0' % (BASE, zone))
    j = _get(url, timeout=12)
    rows = ((j or {}).get('data') or {}).get('data') or []
    best = ''
    for r in rows:
        d = ''.join(ch for ch in str(r.get('issue_no') or '') if ch.isdigit())
        if len(d) > len(best) or (len(d) == len(best) and d > best):
            best = d
    return best, (best[-3:] if len(best) >= 3 else best)


def rows_of(j):
    if not j:
        return []
    d = j.get('data') or {}
    a = d.get('data')
    if isinstance(a, dict):
        a = a.get('data')
    return a if isinstance(a, list) else []


def article_of(j):
    return ((j or {}).get('data') or {}).get('article') or {}


def norm_issue(x):
    s = str(x or '').strip()
    s = s.lstrip('0') or s
    return s


def money_text(x):
    p = x.get('price')
    if p is None or str(p) in ('0', '0.0', ''):
        return '免费'
    return '¥%s' % p


def bg(widget, color):
    from kivy.graphics import Color, Rectangle
    with widget.canvas.before:
        Color(*color)
        r = Rectangle(pos=widget.pos, size=widget.size)

    def _sync(*_):
        r.pos = widget.pos
        r.size = widget.size
    widget.bind(pos=_sync, size=_sync)


class Card(BoxLayout):
    """一条搜索结果卡片"""

    def __init__(self, app, row, **kw):
        super(Card, self).__init__(orientation='vertical', size_hint_y=None,
                                   height=dp(132), padding=(dp(10), dp(8)),
                                   spacing=dp(4), **kw)
        bg(self, C_CARD)
        self.app = app
        self.row = row

        title = Label(text=str(row.get('title') or ''), font_name=FONT, font_size=dp(14),
                      bold=True, color=C_TEXT, halign='left', valign='middle',
                      size_hint_y=None, height=dp(46), shorten=True, shorten_from='right',
                      text_size=(dp(280), dp(46)))
        self.add_widget(title)

        meta = '👤 %s    🏷 %s    📅 %s    %s' % (
            row.get('author') or '', row.get('son_title') or '',
            norm_issue(row.get('issue_no')), money_text(row))
        self.add_widget(Label(text=meta, font_name=FONT, font_size=dp(11), color=C_MUT,
                              halign='left', valign='middle', size_hint_y=None,
                              height=dp(20), shorten=True, shorten_from='right',
                              text_size=(dp(280), dp(20))))

        acts = BoxLayout(size_hint_y=None, height=dp(40), spacing=dp(8))
        b1 = Button(text='⬇ 下载/查看', font_name=FONT, font_size=dp(13),
                    background_normal='', background_color=C_PRIMARY, color=(1, 1, 1, 1))
        b1.bind(on_release=lambda *a: self.app.open_detail(row))
        b2 = Button(text='📋 复制内容', font_name=FONT, font_size=dp(13),
                    background_normal='', background_color=C_ACCENT, color=C_PRIMARY)
        b2.bind(on_release=lambda *a: self.app.copy_row_content(row))
        acts.add_widget(b1)
        acts.add_widget(b2)
        self.add_widget(acts)


class MainUI(BoxLayout):
    def __init__(self, **kw):
        super(MainUI, self).__init__(orientation='vertical', **kw)
        bg(self, C_BG)
        self.page = 1
        self.rows = []
        self.zone = 1
        self.label = '福彩3D'
        self.busy = False

        # ===== 顶部标题栏 =====
        bar = BoxLayout(orientation='horizontal', size_hint_y=None, height=dp(52),
                        padding=(dp(12), 0), spacing=dp(8))
        bg(bar, C_PRIMARY)
        t = Label(text='3D采集', font_name=FONT, font_size=dp(18), bold=True,
                  color=(1, 1, 1, 1), halign='left', valign='middle')
        t.bind(size=lambda *a: setattr(t, 'text_size', (t.width, None)))
        bar.add_widget(t)
        self.sp = Spinner(text='福彩3D', values=[x[0] for x in LOTS], font_name=FONT,
                          font_size=dp(13), size_hint=(None, None), size=(dp(96), dp(34)),
                          background_normal='', background_color=C_PRIMARY2, color=(1, 1, 1, 1))
        self.sp.bind(text=self._on_lot)
        bar.add_widget(self.sp)
        self.add_widget(bar)

        # ===== 搜索区 =====
        box = BoxLayout(orientation='vertical', size_hint_y=None, height=dp(150),
                        padding=(dp(12), dp(10)), spacing=dp(8))
        bg(box, C_CARD)
        row1 = BoxLayout(size_hint_y=None, height=dp(44), spacing=dp(8))
        self.kw = TextInput(hint_text='输入作者 / 小类（如：华迪、8个胆码）', font_name=FONT,
                            font_size=dp(14), multiline=False, background_normal='',
                            background_active='', background_color=(0.97, 0.98, 1, 1),
                            foreground_color=C_TEXT, cursor_color=C_PRIMARY,
                            padding=(dp(10), dp(10)))
        row1.add_widget(self.kw)
        box.add_widget(row1)

        row2 = BoxLayout(size_hint_y=None, height=dp(44), spacing=dp(8))
        self.issue = TextInput(hint_text='期号（自动）', font_name=FONT, font_size=dp(14),
                               multiline=False, input_filter='int', size_hint_x=None,
                               width=dp(110), background_normal='', background_active='',
                               background_color=(0.97, 0.98, 1, 1), foreground_color=C_TEXT,
                               cursor_color=C_PRIMARY, padding=(dp(10), dp(10)))
        row2.add_widget(self.issue)
        self.btn_go = Button(text='搜索', font_name=FONT, font_size=dp(15), bold=True,
                             background_normal='', background_color=C_PRIMARY,
                             color=(1, 1, 1, 1))
        self.btn_go.bind(on_release=lambda *a: self.search(1))
        row2.add_widget(self.btn_go)
        self.btn_latest = Button(text='最新期', font_name=FONT, font_size=dp(13),
                                 background_normal='', background_color=C_ACCENT,
                                 color=C_PRIMARY, size_hint_x=None, width=dp(80))
        self.btn_latest.bind(on_release=lambda *a: self.load_latest_issue(True))
        row2.add_widget(self.btn_latest)
        box.add_widget(row2)
        self.add_widget(box)

        self.status = Label(text='正在获取最新期号…', font_name=FONT, font_size=dp(12),
                            color=C_MUT, size_hint_y=None, height=dp(24),
                            halign='left', valign='middle', padding=(dp(12), 0),
                            shorten=True, shorten_from='right')
        self.status.bind(size=lambda *a: setattr(self.status, 'text_size', (self.status.width, None)))
        self.add_widget(self.status)

        # ===== 结果列表 =====
        self.sv = ScrollView(bar_width=dp(4), scroll_type=['content'])
        self.listbox = BoxLayout(orientation='vertical', size_hint_y=None,
                                 spacing=dp(8), padding=(dp(8), dp(4)))
        self.listbox.bind(minimum_height=self.listbox.setter('height'))
        self.sv.add_widget(self.listbox)
        self.add_widget(self.sv)

        # ===== 底部翻页 =====
        bar2 = BoxLayout(size_hint_y=None, height=dp(52), spacing=dp(8),
                         padding=(dp(10), dp(8)))
        bg(bar2, C_CARD)
        b_prev = Button(text='上一页', font_name=FONT, font_size=dp(13),
                        background_normal='', background_color=C_ACCENT, color=C_PRIMARY)
        b_prev.bind(on_release=lambda *a: self.search(max(1, self.page - 1)))
        self.pg = Label(text='第 1 页', font_name=FONT, font_size=dp(12), color=C_MUT)
        b_next = Button(text='下一页', font_name=FONT, font_size=dp(13),
                        background_normal='', background_color=C_ACCENT, color=C_PRIMARY)
        b_next.bind(on_release=lambda *a: self.search(self.page + 1))
        b_all = Button(text='复制本页全部', font_name=FONT, font_size=dp(13),
                       background_normal='', background_color=C_PRIMARY, color=(1, 1, 1, 1))
        b_all.bind(on_release=lambda *a: self.copy_page())
        bar2.add_widget(b_prev)
        bar2.add_widget(self.pg)
        bar2.add_widget(b_next)
        bar2.add_widget(b_all)
        self.add_widget(bar2)

        Clock.schedule_once(lambda dt: self.load_latest_issue(False), 0.6)

    # ---------- 工具 ----------
    def say(self, msg, secs=3):
        try:
            self.status.text = msg
            Clock.schedule_once(lambda *a: setattr(self.status, 'text', ''), secs)
        except Exception:
            pass

    def _copy(self, txt):
        try:
            Clipboard.copy(txt or '')
            return True
        except Exception as e:
            self.say('复制失败：%s' % e, 5)
            return False

    def _on_lot(self, sp, txt):
        for nm, z in LOTS:
            if nm == txt:
                self.zone = z
                self.label = nm
        self.issue.text = ''
        self.load_latest_issue(False)

    # ---------- 最新期号 ----------
    def load_latest_issue(self, fill):
        zone = self.zone

        def work():
            try:
                full, short = fetch_latest_issue(zone)
                Clock.schedule_once(lambda *a: self._latest_done(full, short, fill), 0)
            except Exception as e:
                log('latest issue fail: %r' % (e,))
                Clock.schedule_once(lambda *a: self.say('最新期号获取失败（可手填）', 6), 0)
        threading.Thread(target=work, daemon=True).start()

    @mainthread
    def _latest_done(self, full, short, fill):
        if short:
            self.issue.text = short      # 自动填最新期（可手改）
        if full:
            self.say('最新期 %s（搜索默认按这一期）' % full, 6)
        else:
            self.say('没取到最新期号，可手动填期号', 6)

    # ---------- 搜索 ----------
    def search(self, page):
        if self.busy:
            return
        if page < 1:
            page = 1
        self.busy = True
        self.btn_go.disabled = True
        self.say('搜索中…', 30)
        kw = (self.kw.text or '').strip()
        issue = (self.issue.text or '').strip()
        zone = self.zone

        def work():
            try:
                j = fetch_search(kw, issue, zone, page)
                rows = rows_of(j)
                note = ''
                if not rows and issue:
                    # 该期还没人发这个作者/小类 → 自动退回不限期号再搜一次
                    j2 = fetch_search(kw, '', zone, page)
                    rows = rows_of(j2)
                    if rows:
                        note = '「%s期」没搜到，已按不限期号显示' % issue
                Clock.schedule_once(lambda *a: self._rows_done(rows, page, note), 0)
            except Exception as e:
                log('search fail: %r\n%s' % (e, traceback.format_exc()))
                Clock.schedule_once(lambda *a: self._fail('搜索失败', e), 0)
        threading.Thread(target=work, daemon=True).start()

    @mainthread
    def _fail(self, title, err):
        self.busy = False
        self.btn_go.disabled = False
        self.say('%s：%s' % (title, err), 6)
        try:
            Popup(title=title, content=Label(text=str(err)[:400], font_name=FONT,
                                             font_size=dp(12), color=C_TEXT),
                  size_hint=(0.9, 0.45)).open()
        except Exception:
            pass

    @mainthread
    def _rows_done(self, rows, page, note=''):
        try:
            self.busy = False
            self.btn_go.disabled = False
            self.rows = rows
            self.page = page
            self.listbox.clear_widgets()
            if not rows:
                self.listbox.add_widget(Label(text='没有结果\n换个作者/小类，或点「最新期」', font_name=FONT,
                                              font_size=dp(13), color=C_MUT, size_hint_y=None,
                                              height=dp(90)))
                self.pg.text = '第 %d 页' % page
                self.say('没有结果', 4)
                return
            app = App.get_running_app()
            for r in rows:
                self.listbox.add_widget(Card(app, r))
            self.sv.scroll_y = 1
            self.pg.text = '第 %d 页 · %d 条' % (page, len(rows))
            self.say(note or ('本页 %d 条' % len(rows)), 6 if note else 4)
        except Exception as e:
            log('render fail: %r\n%s' % (e, traceback.format_exc()))
            self._fail('界面渲染出错', e)

    # ---------- 详情 ----------
    def open_detail(self, row):
        self.say('读取中…', 30)
        ident = row.get('id')

        def work():
            try:
                art = article_of(fetch_show(ident))
                Clock.schedule_once(lambda *a: self._detail_done(row, art), 0)
            except Exception as e:
                log('detail fail: %r' % (e,))
                Clock.schedule_once(lambda *a: self._fail('读取失败', e), 0)
        threading.Thread(target=work, daemon=True).start()

    @mainthread
    def _detail_done(self, row, art):
        try:
            title = str(art.get('title') or row.get('title') or '')
            body = str(art.get('content') if art.get('content') is not None else '')
            meta = '作者 %s   小类 %s   期号 %s   原文 %s 字' % (
                art.get('author') or row.get('author') or '',
                art.get('son_title') or row.get('son_title') or '',
                norm_issue(art.get('issue_no') or row.get('issue_no')),
                art.get('content_len') or len(body))
            box = BoxLayout(orientation='vertical', padding=dp(10), spacing=dp(8))
            bg(box, C_CARD)
            box.add_widget(Label(text=title, font_name=FONT, font_size=dp(14), bold=True,
                                 color=C_TEXT, size_hint_y=None, height=dp(44),
                                 halign='left', valign='middle', shorten=True,
                                 shorten_from='right'))
            box.add_widget(Label(text=meta, font_name=FONT, font_size=dp(11), color=C_MUT,
                                 size_hint_y=None, height=dp(20)))
            sv = ScrollView()
            ti = TextInput(text=body, readonly=True, font_name=FONT, font_size=dp(14),
                           background_normal='', background_active='',
                           background_color=(0.97, 0.98, 1, 1), foreground_color=C_TEXT,
                           cursor_color=C_PRIMARY)
            sv.add_widget(ti)
            box.add_widget(sv)
            acts = BoxLayout(size_hint_y=None, height=dp(44), spacing=dp(8))
            b1 = Button(text='📋 复制内容', font_name=FONT, font_size=dp(13),
                        background_normal='', background_color=C_PRIMARY, color=(1, 1, 1, 1))
            b2 = Button(text='📋 标题+内容', font_name=FONT, font_size=dp(13),
                        background_normal='', background_color=C_ACCENT, color=C_PRIMARY)
            b3 = Button(text='关闭', font_name=FONT, font_size=dp(13),
                        background_normal='', background_color=(0.90, 0.91, 0.94, 1), color=C_TEXT)
            pop = Popup(title='内容（条件原样）', content=box, size_hint=(0.96, 0.9),
                        title_font=FONT, title_color=C_TEXT, separator_color=C_LINE)
            b1.bind(on_release=lambda *a: (self._copy(body), self.say('内容已复制', 3)))
            b2.bind(on_release=lambda *a: (self._copy('【%s】\n%s\n%s' % (title, meta, body)),
                                           self.say('标题+内容已复制', 3)))
            b3.bind(on_release=lambda *a: pop.dismiss())
            acts.add_widget(b1)
            acts.add_widget(b2)
            acts.add_widget(b3)
            box.add_widget(acts)
            pop.open()
            self.say('已下载（原样显示）', 4)
        except Exception as e:
            log('detail render fail: %r\n%s' % (e, traceback.format_exc()))
            self._fail('显示失败', e)

    # ---------- 复制 ----------
    def copy_row_content(self, row):
        self.say('读取中…', 30)
        ident = row.get('id')

        def work():
            try:
                art = article_of(fetch_show(ident))
                body = str(art.get('content') if art.get('content') is not None else '')
                n = len([x for x in body.split() if x])
                Clock.schedule_once(lambda *a: (self._copy(body), self.say('已复制 %d 项' % n, 4)), 0)
            except Exception as e:
                log('copy fail: %r' % (e,))
                Clock.schedule_once(lambda *a: self._fail('复制失败', e), 0)
        threading.Thread(target=work, daemon=True).start()

    def copy_page(self):
        if not self.rows:
            self.say('先搜索', 3)
            return
        self.say('正在逐条读取…', 60)
        rows = list(self.rows)

        def work():
            out = []
            for r in rows:
                try:
                    art = article_of(fetch_show(r.get('id')))
                    out.append('【%s】\n%s' % (art.get('title') or r.get('title') or '',
                                              art.get('content') if art.get('content') is not None else ''))
                except Exception:
                    out.append('【%s】\n（读取失败）' % (r.get('title') or ''))
            Clock.schedule_once(lambda *a: (self._copy('\n\n'.join(out)),
                                            self.say('已复制本页 %d 条' % len(rows), 4)), 0)
        threading.Thread(target=work, daemon=True).start()


class MobileApp(App):
    title = '3D采集 · 手机版'

    def build(self):
        Window.clearcolor = C_BG
        return MainUI()


if __name__ == '__main__':
    try:
        MobileApp().run()
    except Exception:
        log('fatal:\n%s' % traceback.format_exc())
        raise
