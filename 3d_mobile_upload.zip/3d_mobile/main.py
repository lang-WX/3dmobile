# -*- coding: utf-8 -*-
"""
3D采集 · 手机版（安卓，Kivy）
--------------------------------
只做两件事：① 站内搜索  ② 下载查看原文（条件保持原样，不做任何转换）
不导出 Excel，不写文件；需要数据就点「复制」。

无第三方依赖：网络用标准库 urllib，剪贴板用 Kivy Clipboard。
"""
import json
import os
import threading
import urllib.parse
import urllib.request

from kivy.app import App
from kivy.clock import Clock, mainthread
from kivy.core.clipboard import Clipboard
from kivy.core.text import LabelBase
from kivy.metrics import dp
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.popup import Popup
from kivy.uix.scrollview import ScrollView
from kivy.uix.spinner import Spinner
from kivy.uix.textinput import TextInput

BASE = 'https://app.weice888.cn'
UA = ('Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 '
      '(KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36')
LOTS = [('福彩3D', 1), ('排列三', 2), ('双色球', 5)]

_HERE = os.path.dirname(os.path.abspath(__file__))
_FONT = os.path.join(_HERE, 'fonts', 'msyh.ttc')
if os.path.exists(_FONT):
    try:
        LabelBase.register(name='cjk', fn_regular=_FONT)
        FONT = 'cjk'
    except Exception:
        FONT = 'Roboto'
else:
    FONT = 'Roboto'


# ---------------- 网络（纯标准库） ----------------
def _get(url):
    req = urllib.request.Request(url, headers={
        'User-Agent': UA,
        'Accept': 'application/json, text/plain, */*',
    })
    with urllib.request.urlopen(req, timeout=20) as r:
        return json.loads(r.read().decode('utf-8'))


def build_query(kw, issue):
    parts = []
    if issue:
        parts.append(str(issue).strip() + '期')
    if kw:
        parts.append(str(kw).strip())
    return ' '.join(parts).strip()


def fetch_search(kw, issue, zone, page=1):
    q = build_query(kw, issue)
    url = ('%s/addons/ask/api.search/index?module=article&q=%s&page=%d&zone_id=%d'
           % (BASE, urllib.parse.quote(q), page, zone))
    return _get(url)


def fetch_show(aid):
    url = '%s/addons/ask/api.article/show?id=%s&order=default' % (BASE, urllib.parse.quote(str(aid)))
    return _get(url)


def rows_of(j):
    if not j:
        return []
    d = j.get('data') or {}
    a = d.get('data')
    if isinstance(a, dict):
        a = a.get('data')
    return a if isinstance(a, list) else []


def article_of(j):
    return ((j or {}).get('data') or {}).get('article') or {}


def norm_issue(x):
    s = str(x or '').strip()
    return s.lstrip('0') or s


def money_text(x):
    p = x.get('price')
    if p is None or str(p) in ('0', '0.0', ''):
        return '免费'
    return '¥%s' % p


# ---------------- UI ----------------
class Card(BoxLayout):
    def __init__(self, app, row, **kw):
        super(Card, self).__init__(orientation='vertical', size_hint_y=None,
                                   padding=(dp(8), dp(6)), spacing=dp(2), **kw)
        self.app = app
        self.row = row
        title = TextInput(text=str(row.get('title') or ''), readonly=True,
                          multiline=True, font_name=FONT, font_size=dp(13),
                          size_hint_y=None, height=dp(44),
                          background_color=(1, 1, 1, 1), foreground_color=(0.1, 0.12, 0.16, 1),
                          cursor_color=(0, 0, 0, 0), padding=(dp(6), dp(4)))
        self.add_widget(title)
        meta = '👤 %s   🏷 %s   📅 %s   %s   连红 %s  命中 %s' % (
            row.get('author') or '', row.get('son_title') or '',
            norm_issue(row.get('issue_no')), money_text(row),
            row.get('lianzhong', '-'), row.get('jinzhong', '-'))
        self.add_widget(Label(text=meta, font_name=FONT, font_size=dp(11),
                              color=(0.45, 0.5, 0.58, 1), size_hint_y=None,
                              height=dp(18), halign='left', valign='middle',
                              text_size=(dp(300), dp(18))))
        acts = BoxLayout(size_hint_y=None, height=dp(34), spacing=dp(6))
        b1 = Button(text='⬇ 下载/查看', font_name=FONT, font_size=dp(12),
                    background_color=(0.1, 0.14, 0.5, 1))
        b1.bind(on_release=lambda *a: self.app.open_detail(row))
        b2 = Button(text='📋 复制内容', font_name=FONT, font_size=dp(12),
                    background_color=(0.93, 0.94, 1, 1), color=(0.1, 0.14, 0.5, 1))
        b2.bind(on_release=lambda *a: self.app.copy_row_content(row))
        acts.add_widget(b1)
        acts.add_widget(b2)
        self.add_widget(acts)


class MainUI(BoxLayout):
    def __init__(self, **kw):
        super(MainUI, self).__init__(orientation='vertical', padding=dp(6), spacing=dp(6), **kw)
        self.page = 1
        self.rows = []
        self.zone = 1
        self.label = '福彩3D'

        # 顶部参数
        top = BoxLayout(size_hint_y=None, height=dp(40), spacing=dp(4))
        self.sp = Spinner(text='福彩3D', values=[x[0] for x in LOTS],
                          font_name=FONT, font_size=dp(12), size_hint_x=None, width=dp(92))
        self.sp.bind(text=self._on_lot)
        self.kw = TextInput(hint_text='作者/小类/标题', font_name=FONT, font_size=dp(13),
                            multiline=False)
        self.issue = TextInput(hint_text='期号', font_name=FONT, font_size=dp(13),
                               multiline=False, size_hint_x=None, width=dp(78),
                               input_filter='int')
        b = Button(text='搜索', font_name=FONT, font_size=dp(13), size_hint_x=None,
                   width=dp(62), background_color=(0.1, 0.14, 0.5, 1))
        b.bind(on_release=lambda *a: self.search(1))
        top.add_widget(self.sp)
        top.add_widget(self.kw)
        top.add_widget(self.issue)
        top.add_widget(b)
        self.add_widget(top)

        self.status = Label(text='输入作者或小类，点搜索', font_name=FONT, font_size=dp(11),
                            color=(0.45, 0.5, 0.58, 1), size_hint_y=None, height=dp(20),
                            halign='left', valign='middle')
        self.status.bind(size=lambda *a: setattr(self.status, 'text_size', (self.status.width, None)))
        self.add_widget(self.status)

        # 列表
        self.sv = ScrollView()
        self.listbox = BoxLayout(orientation='vertical', size_hint_y=None,
                                 spacing=dp(4), padding=(0, dp(2)))
        self.listbox.bind(minimum_height=self.listbox.setter('height'))
        self.sv.add_widget(self.listbox)
        self.add_widget(self.sv)

        # 底部
        bar = BoxLayout(size_hint_y=None, height=dp(40), spacing=dp(6))
        self.b_prev = Button(text='上一页', font_name=FONT, font_size=dp(12),
                             background_color=(0.9, 0.92, 1, 1), color=(0.1, 0.14, 0.5, 1))
        self.b_prev.bind(on_release=lambda *a: self.search(max(1, self.page - 1)))
        self.pg = Label(text='第 1 页', font_name=FONT, font_size=dp(12),
                        color=(0.45, 0.5, 0.58, 1))
        self.b_next = Button(text='下一页', font_name=FONT, font_size=dp(12),
                             background_color=(0.9, 0.92, 1, 1), color=(0.1, 0.14, 0.5, 1))
        self.b_next.bind(on_release=lambda *a: self.search(self.page + 1))
        self.b_all = Button(text='复制本页全部', font_name=FONT, font_size=dp(12),
                            background_color=(0.1, 0.14, 0.5, 1))
        self.b_all.bind(on_release=lambda *a: self.copy_page())
        bar.add_widget(self.b_prev)
        bar.add_widget(self.pg)
        bar.add_widget(self.b_next)
        bar.add_widget(self.b_all)
        self.add_widget(bar)

    def _on_lot(self, sp, txt):
        for nm, z in LOTS:
            if nm == txt:
                self.zone = z
                self.label = nm

    def say(self, msg, secs=2.5):
        self.status.text = msg
        Clock.schedule_once(lambda *a: setattr(self.status, 'text', ''), secs)

    # ---- 搜索 ----
    def search(self, page):
        if page < 1:
            page = 1
        self.say('搜索中…', 30)
        kw = self.kw.text.strip()
        issue = self.issue.text.strip()

        def work():
            try:
                j = fetch_search(kw, issue, self.zone, page)
                rows = rows_of(j)
                Clock.schedule_once(lambda *a: self.show_rows(rows, page), 0)
            except Exception as e:
                Clock.schedule_once(lambda *a: self.say('搜索失败：%s' % e, 6), 0)
        threading.Thread(target=work, daemon=True).start()

    @mainthread
    def show_rows(self, rows, page):
        self.rows = rows
        self.page = page
        self.listbox.clear_widgets()
        if not rows:
            self.listbox.add_widget(Label(text='没有结果，换个关键词试试', font_name=FONT,
                                          size_hint_y=None, height=dp(60),
                                          color=(0.5, 0.55, 0.6, 1)))
            self.pg.text = '第 %d 页' % page
            self.say('没有结果')
            return
        for r in rows:
            self.listbox.add_widget(Card(App.get_running_app(), r))
        self.pg.text = '第 %d 页 · %d 条' % (page, len(rows))
        self.say('共搜到 %d 条（本页）' % len(rows))

    # ---- 详情（条件原样） ----
    def open_detail(self, row):
        self.say('读取中…', 30)

        def work():
            try:
                j = fetch_show(row.get('id'))
                art = article_of(j)
                Clock.schedule_once(lambda *a: self._show_detail(row, art), 0)
            except Exception as e:
                Clock.schedule_once(lambda *a: self.say('读取失败：%s' % e, 6), 0)
        threading.Thread(target=work, daemon=True).start()

    @mainthread
    def _show_detail(self, row, art):
        title = str(art.get('title') or row.get('title') or '')
        body = str(art.get('content') if art.get('content') is not None else '')
        meta = '作者 %s  小类 %s  期号 %s  原文 %s 字' % (
            art.get('author') or row.get('author') or '',
            art.get('son_title') or row.get('son_title') or '',
            norm_issue(art.get('issue_no') or row.get('issue_no')),
            art.get('content_len') or len(body))
        box = BoxLayout(orientation='vertical', padding=dp(8), spacing=dp(6))
        box.add_widget(Label(text=title, font_name=FONT, font_size=dp(13), size_hint_y=None,
                             height=dp(40), halign='left', valign='middle',
                             text_size=(dp(300), dp(40))))
        box.add_widget(Label(text=meta, font_name=FONT, font_size=dp(11),
                             color=(0.45, 0.5, 0.58, 1), size_hint_y=None, height=dp(18)))
        sv = ScrollView()
        ti = TextInput(text=body, readonly=True, font_name=FONT, font_size=dp(13),
                       background_color=(0.97, 0.97, 1, 1), foreground_color=(0.1, 0.12, 0.16, 1))
        sv.add_widget(ti)
        box.add_widget(sv)
        acts = BoxLayout(size_hint_y=None, height=dp(38), spacing=dp(6))
        b1 = Button(text='📋 复制内容', font_name=FONT, font_size=dp(12),
                    background_color=(0.1, 0.14, 0.5, 1))
        b2 = Button(text='📋 标题+内容', font_name=FONT, font_size=dp(12),
                    background_color=(0.9, 0.92, 1, 1), color=(0.1, 0.14, 0.5, 1))
        b3 = Button(text='关闭', font_name=FONT, font_size=dp(12),
                    background_color=(0.9, 0.9, 0.93, 1), color=(0.2, 0.2, 0.2, 1))
        pop = Popup(title='内容（条件原样）', content=box, size_hint=(0.97, 0.9))
        b1.bind(on_release=lambda *a: (self._copy(body), self.say('内容已复制')))
        b2.bind(on_release=lambda *a: (self._copy('【%s】\n%s\n%s' % (title, meta, body)),
                                       self.say('标题+内容已复制')))
        b3.bind(on_release=lambda *a: pop.dismiss())
        acts.add_widget(b1)
        acts.add_widget(b2)
        acts.add_widget(b3)
        box.add_widget(acts)
        pop.open()
        self.say('已下载（原样显示）')

    # ---- 复制 ----
    def _copy(self, txt):
        try:
            Clipboard.copy(txt or '')
            return True
        except Exception as e:
            self.say('复制失败：%s' % e, 4)
            return False

    def copy_row_content(self, row):
        self.say('读取中…', 30)

        def work():
            try:
                art = article_of(fetch_show(row.get('id')))
                body = str(art.get('content') if art.get('content') is not None else '')
                n = len([x for x in body.split() if x])
                Clock.schedule_once(lambda *a: (self._copy(body),
                                                self.say('已复制 %d 项' % n, 3)), 0)
            except Exception as e:
                Clock.schedule_once(lambda *a: self.say('读取失败：%s' % e, 6), 0)
        threading.Thread(target=work, daemon=True).start()

    def copy_page(self):
        if not self.rows:
            self.say('先搜索')
            return
        self.say('正在逐条读取…', 60)
        rows = list(self.rows)

        def work():
            out = []
            for r in rows:
                try:
                    art = article_of(fetch_show(r.get('id')))
                    out.append('【%s】\n%s' % (
                        art.get('title') or r.get('title') or '',
                        art.get('content') if art.get('content') is not None else ''))
                except Exception:
                    out.append('【%s】\n（读取失败）' % (r.get('title') or ''))
            txt = '\n\n'.join(out)
            Clock.schedule_once(lambda *a: (self._copy(txt),
                                            self.say('已复制本页 %d 条' % len(rows), 4)), 0)
        threading.Thread(target=work, daemon=True).start()


class MobileApp(App):
    title = '3D采集 · 手机版'

    def build(self):
        return MainUI()


if __name__ == '__main__':
    MobileApp().run()
